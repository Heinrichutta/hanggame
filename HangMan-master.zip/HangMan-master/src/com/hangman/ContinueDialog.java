package com.hangman;

public class ContinueDialog {

}
