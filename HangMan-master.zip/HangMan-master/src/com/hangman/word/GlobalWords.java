package com.hangman.word;

import java.util.ArrayList;

public interface GlobalWords {
    public char[] wordList = null;
    public ArrayList<WordStructure> structuredWordList = new ArrayList<WordStructure>();     
}
